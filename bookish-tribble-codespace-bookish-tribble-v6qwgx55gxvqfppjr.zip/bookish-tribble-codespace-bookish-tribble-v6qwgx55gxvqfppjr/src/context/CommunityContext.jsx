import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { communityArticles as seedCommunityArticles } from "../data/communityArticles";

const USERS_KEY = "envirocore-community-users";
const SESSION_KEY = "envirocore-community-session";
const POSTS_KEY = "envirocore-community-posts";
const ADMIN_EMAILS = new Set(["admin@envirocore.com"]);
const DEFAULT_PUBLISHED_ISO = "2026-04-28T12:00:00.000Z";

const CommunityContext = createContext(null);

function loadJson(key, fallback) {
  if (typeof window === "undefined") return fallback;

  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function saveJson(key, value) {
  window.localStorage.setItem(key, JSON.stringify(value));
}

function slugify(value) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

function formatPublishedDate(date = new Date()) {
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "2-digit",
    year: "numeric",
  }).format(new Date(date));
}

function buildSections(body) {
  return body
    .split(/\n\s*\n/g)
    .map((paragraph) => paragraph.trim())
    .filter(Boolean)
    .map((paragraph, index) => ({
      heading: index === 0 ? "Overview" : `Section ${index + 1}`,
      body: paragraph,
    }));
}

function sectionsToMarkdown(sections = []) {
  if (!Array.isArray(sections) || !sections.length) {
    return "";
  }

  return sections.map((section) => `## ${section.heading}\n\n${section.body}`).join("\n\n");
}

function normalizePhone(phone = "") {
  return phone.replace(/[()\-\s]/g, "").trim();
}

function normalizeRole(user = {}) {
  if (user.role) {
    return user.role;
  }

  if (user.email && ADMIN_EMAILS.has(user.email.toLowerCase())) {
    return "admin";
  }

  return "author";
}

function normalizeUser(user = {}) {
  return {
    id: user.id ?? Date.now().toString(36),
    name: user.name ?? "Community Member",
    email: user.email ?? "",
    phone: user.phone ?? "",
    password: user.password ?? "",
    verified: Boolean(user.verified),
    role: normalizeRole(user),
    verificationMethod: user.verificationMethod ?? (user.email ? "email" : "phone"),
    verificationTarget: user.verificationTarget ?? user.email ?? user.phone ?? "",
    verificationCode: user.verificationCode ?? null,
    verificationCodeIssuedAt: user.verificationCodeIssuedAt ?? null,
  };
}

function normalizeWorkflowStatus(status) {
  const allowed = new Set(["published", "draft", "scheduled", "pending", "rejected"]);
  return allowed.has(status) ? status : "published";
}

function derivePublishedLabel(article) {
  if (article.status === "draft") {
    return "Draft";
  }

  if (article.status === "pending") {
    return "Pending review";
  }

  if (article.status === "scheduled") {
    return article.scheduledForISO ? `Scheduled for ${formatPublishedDate(article.scheduledForISO)}` : "Scheduled";
  }

  if (article.status === "rejected") {
    return "Rejected";
  }

  if (article.publishedAt) {
    return article.publishedAt;
  }

  if (article.publishedAtISO) {
    return formatPublishedDate(article.publishedAtISO);
  }

  return formatPublishedDate(DEFAULT_PUBLISHED_ISO);
}

function normalizeArticle(article = {}) {
  const status = normalizeWorkflowStatus(article.status);
  const publishedAtISO = article.publishedAtISO ?? (status === "published" ? DEFAULT_PUBLISHED_ISO : null);
  const scheduledForISO = article.scheduledForISO ?? article.scheduledFor ?? null;
  const bodyMarkdown = article.bodyMarkdown ?? sectionsToMarkdown(article.sections);
  const takeaways = Array.isArray(article.takeaways)
    ? article.takeaways.map((item) => item.trim()).filter(Boolean)
    : typeof article.takeaways === "string"
      ? article.takeaways
          .split(/\n+/g)
          .map((item) => item.trim())
          .filter(Boolean)
      : [];

  const normalized = {
    featured: false,
    author: "Engr. Saeed Ur Rehman Samoo",
    authorId: "envirocore-editorial",
    authorRole: "editorial",
    coverImage: "",
    bodyMarkdown: "",
    viewCount: 0,
    status: "published",
    reviewNote: "",
    updatedAtISO: null,
    publishedAtISO: DEFAULT_PUBLISHED_ISO,
    scheduledForISO: null,
    ...article,
    publishedAt: derivePublishedLabel({
      ...article,
      status,
      publishedAtISO,
      scheduledForISO,
    }),
  };

  return {
    ...normalized,
    status,
    bodyMarkdown,
    takeaways,
    publishedAtISO,
    scheduledForISO,
    author: normalized.author ?? "Engr. Saeed Ur Rehman Samoo",
    authorId: normalized.authorId ?? (normalized.author ? slugify(normalized.author) : "envirocore-editorial"),
    authorRole: normalized.authorRole ?? (normalized.authorId === "envirocore-editorial" ? "editorial" : "author"),
    featured: Boolean(normalized.featured),
    coverImage: normalized.coverImage ?? "",
    reviewNote: normalized.reviewNote ?? "",
    updatedAtISO: normalized.updatedAtISO ?? null,
  };
}

function normalizeSession(session = null) {
  if (!session) {
    return null;
  }

  return {
    id: session.id,
    name: session.name ?? "Community Member",
    email: session.email ?? "",
    phone: session.phone ?? "",
    verified: Boolean(session.verified),
    role: normalizeRole(session),
    verificationMethod: session.verificationMethod ?? (session.email ? "email" : "phone"),
    verificationTarget: session.verificationTarget ?? session.email ?? session.phone ?? "",
  };
}

function resolveArticlePublication(article, now = Date.now()) {
  if (article.status !== "scheduled" || !article.scheduledForISO) {
    return article;
  }

  const scheduledTime = new Date(article.scheduledForISO).getTime();

  if (Number.isNaN(scheduledTime) || scheduledTime > now) {
    return article;
  }

  return {
    ...article,
    status: "published",
    publishedAtISO: article.scheduledForISO,
    publishedAt: formatPublishedDate(article.scheduledForISO),
    scheduledForISO: null,
  };
}

function isPublicArticle(article) {
  return article.status === "published";
}

function generateVerificationCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function buildPublishedPost(input, session, existingPost = null) {
  const workflow = normalizeWorkflowStatus(input.workflow ?? "published");
  const now = new Date();
  const scheduledForISO = workflow === "scheduled" && input.scheduledFor ? new Date(input.scheduledFor).toISOString() : null;
  const publishedAtISO = workflow === "published" ? now.toISOString() : existingPost?.publishedAtISO ?? null;
  const slug = existingPost?.slug ?? `${slugify(input.title)}-${Date.now().toString(36)}`;

  return {
    slug,
    type: input.type,
    category: input.category,
    title: input.title.trim(),
    readTime: input.readTime.trim(),
    excerpt: input.excerpt.trim(),
    coverImage: input.coverImage?.trim() ?? "",
    featured: Boolean(input.featured),
    author: existingPost?.author ?? session.name,
    authorId: existingPost?.authorId ?? session.id,
    authorRole: session.role,
    bodyMarkdown: input.bodyMarkdown.trim(),
    sections: buildSections(input.bodyMarkdown.trim()),
    takeaways: input.takeaways
      .split(/\n+/g)
      .map((item) => item.trim())
      .filter(Boolean),
    workflow,
    status: workflow,
    publishedAtISO,
    publishedAt: workflow === "published" ? formatPublishedDate(now) : workflow === "scheduled" ? derivePublishedLabel({ status: workflow, scheduledForISO }) : derivePublishedLabel({ status: workflow }),
    scheduledForISO,
    reviewNote: input.reviewNote?.trim() ?? existingPost?.reviewNote ?? "",
    updatedAtISO: now.toISOString(),
    viewCount: existingPost?.viewCount ?? 0,
  };
}

export function CommunityProvider({ children }) {
  const [users, setUsers] = useState(() => loadJson(USERS_KEY, []).map(normalizeUser));
  const [session, setSession] = useState(() => normalizeSession(loadJson(SESSION_KEY, null)));
  const [userPosts, setUserPosts] = useState(() => loadJson(POSTS_KEY, []).map(normalizeArticle));

  useEffect(() => {
    saveJson(USERS_KEY, users);
  }, [users]);

  useEffect(() => {
    saveJson(SESSION_KEY, session);
  }, [session]);

  useEffect(() => {
    saveJson(POSTS_KEY, userPosts);
  }, [userPosts]);

  useEffect(() => {
    const promoteScheduledPosts = () => {
      const now = Date.now();

      setUserPosts((current) => {
        let changed = false;
        const next = current.map((post) => {
          const normalizedPost = normalizeArticle(post);
          const resolvedPost = resolveArticlePublication(normalizedPost, now);

          if (resolvedPost.status !== normalizedPost.status || resolvedPost.publishedAtISO !== normalizedPost.publishedAtISO) {
            changed = true;
            return resolvedPost;
          }

          return normalizedPost;
        });

        return changed ? next : current;
      });
    };

    promoteScheduledPosts();

    const interval = window.setInterval(promoteScheduledPosts, 30000);
    return () => window.clearInterval(interval);
  }, []);

  const normalizedSeedArticles = useMemo(() => seedCommunityArticles.map(normalizeArticle), []);

  const normalizedUserArticles = useMemo(
    () => userPosts.map(normalizeArticle).map((article) => resolveArticlePublication(article)),
    [userPosts]
  );

  const articles = useMemo(() => {
    return [...normalizedUserArticles.filter(isPublicArticle), ...normalizedSeedArticles.filter(isPublicArticle)];
  }, [normalizedUserArticles, normalizedSeedArticles]);

  const allArticles = useMemo(() => {
    return [...normalizedUserArticles, ...normalizedSeedArticles];
  }, [normalizedUserArticles, normalizedSeedArticles]);

  const featuredArticle = useMemo(() => {
    return articles.find((article) => article.featured) ?? articles[0] ?? null;
  }, [articles]);

  const stats = useMemo(() => {
    const verifiedUsers = users.filter((user) => user.verified).length;
    const draftCount = allArticles.filter((article) => article.status === "draft").length;
    const pendingCount = allArticles.filter((article) => article.status === "pending").length;
    const scheduledCount = allArticles.filter((article) => article.status === "scheduled").length;
    const publishedCount = allArticles.filter((article) => article.status === "published").length;
    const rejectedCount = allArticles.filter((article) => article.status === "rejected").length;
    const totalViews = allArticles.reduce((sum, article) => sum + (article.viewCount ?? 0), 0);

    return {
      users: users.length,
      verifiedUsers,
      draftCount,
      pendingCount,
      scheduledCount,
      publishedCount,
      rejectedCount,
      totalViews,
    };
  }, [users, allArticles]);

  const signup = ({ name, email, phone, password }) => {
    const trimmedName = name.trim();
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedPhone = normalizePhone(phone);

    if (!trimmedName) {
      return { ok: false, message: "Enter a display name." };
    }

    if (!trimmedEmail && !trimmedPhone) {
      return { ok: false, message: "Provide either an email or a phone number." };
    }

    const existingUser = users.find(
      (user) =>
        (trimmedEmail && user.email === trimmedEmail) ||
        (trimmedPhone && normalizePhone(user.phone) === trimmedPhone)
    );

    if (existingUser) {
      return { ok: false, message: "An account already exists with this email or phone number." };
    }

    const verificationMethod = trimmedEmail ? "email" : "phone";
    const verificationTarget = trimmedEmail || trimmedPhone;
    const verificationCode = generateVerificationCode();
    const role = ADMIN_EMAILS.has(trimmedEmail) ? "admin" : "author";

    const newUser = normalizeUser({
      id: Date.now().toString(36),
      name: trimmedName,
      email: trimmedEmail,
      phone: trimmedPhone,
      password,
      verified: false,
      role,
      verificationMethod,
      verificationTarget,
      verificationCode,
      verificationCodeIssuedAt: Date.now(),
    });

    setUsers((current) => [...current, newUser]);
    setSession({
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
      phone: newUser.phone,
      verified: newUser.verified,
      role: newUser.role,
      verificationMethod: newUser.verificationMethod,
      verificationTarget: newUser.verificationTarget,
    });

    return {
      ok: true,
      verificationRequired: true,
      verificationMethod,
      verificationTarget,
      verificationCode,
    };
  };

  const login = ({ identity, password }) => {
    const normalizedIdentity = identity.trim().toLowerCase();
    const normalizedPhoneIdentity = normalizePhone(identity);
    const match = users.find(
      (user) =>
        ((user.email && user.email === normalizedIdentity) ||
          (user.phone && normalizePhone(user.phone) === normalizedPhoneIdentity)) &&
        user.password === password
    );

    if (!match) {
      return { ok: false, message: "Invalid email/phone or password." };
    }

    const normalizedUser = normalizeUser(match);

    setSession({
      id: normalizedUser.id,
      name: normalizedUser.name,
      email: normalizedUser.email,
      phone: normalizedUser.phone,
      verified: Boolean(normalizedUser.verified),
      role: normalizedUser.role,
      verificationMethod: normalizedUser.verificationMethod,
      verificationTarget: normalizedUser.verificationTarget,
    });

    return {
      ok: true,
      verificationRequired: !normalizedUser.verified,
      verificationMethod: normalizedUser.verificationMethod,
      verificationTarget: normalizedUser.verificationTarget,
      verificationCode: normalizedUser.verificationCode,
    };
  };

  const logout = () => setSession(null);

const API_URL = typeof window !== "undefined" ? (window.location.hostname === "localhost" ? "http://localhost:3001" : "") : "";

async function sendVerificationEmail(email, code, name) {
  if (!API_URL) {
    console.log(`[Demo] Verification code ${code} for ${email}`);
    return { ok: true, demo: true };
  }

  try {
    const response = await fetch(`${API_URL}/api/send-verification-code`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, code, name }),
    });

    const data = await response.json();
    return { ok: data.ok, demo: data.demo, error: data.error };
  } catch (error) {
    console.error("Email send failed:", error);
    return { ok: false, error: error.message };
  }
}

async function sendApprovalEmail(authorEmail, authorName, title, status, reviewNote) {
  if (!API_URL) {
    console.log(`[Demo] Would send ${status} email to ${authorEmail} for "${title}"`);
    return { ok: true, demo: true };
  }

  try {
    const response = await fetch(`${API_URL}/api/send-approval-email`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ authorEmail, authorName, title, status, reviewNote }),
    });

    const data = await response.json();
    return { ok: data.ok, demo: data.demo, error: data.error };
  } catch (error) {
    console.error("Email send failed:", error);
    return { ok: false, error: error.message };
  }
}

  const sendVerificationCode = () => {
    if (!session) {
      return { ok: false, message: "Sign in first to request verification." };
    }

    const verificationCode = generateVerificationCode();

    setUsers((current) =>
      current.map((user) =>
        user.id === session.id
          ? {
              ...normalizeUser(user),
              verificationCode,
              verificationCodeIssuedAt: Date.now(),
            }
          : normalizeUser(user)
      )
    );

    sendVerificationEmail(session.email || session.phone, verificationCode, session.name).then((result) => {
      if (result.ok) {
        console.log(`Verification code sent to ${result.demo ? "[demo]" : ""} ${session.email || session.phone}`);
      } else {
        console.error("Failed to send verification email:", result.error);
      }
    });

    return {
      ok: true,
      verificationMethod: session.verificationMethod,
      verificationTarget: session.verificationTarget,
      sent: true,
    };
  };

  const verifyCurrentUser = (code) => {
    if (!session) {
      return { ok: false, message: "Sign in first to verify your account." };
    }

    const match = users.find((user) => user.id === session.id);

    if (!match) {
      return { ok: false, message: "Account not found." };
    }

    if (!match.verificationCode || match.verificationCode !== code.trim()) {
      return { ok: false, message: "Invalid verification code." };
    }

    setUsers((current) =>
      current.map((user) =>
        user.id === session.id
          ? {
              ...normalizeUser(user),
              verified: true,
              verificationCode: null,
              verificationCodeIssuedAt: null,
            }
          : normalizeUser(user)
      )
    );

    setSession((current) =>
      current
        ? {
            ...current,
            verified: true,
          }
        : current
    );

    return { ok: true };
  };

  const saveArticle = (input) => {
    if (!session) {
      return { ok: false, message: "You need to sign in before publishing." };
    }

    if (!session.verified) {
      return {
        ok: false,
        message: "Please verify your account via email or phone before publishing.",
      };
    }

    const requiredFields = ["title", "category", "type", "excerpt", "readTime", "bodyMarkdown", "takeaways"];
    const hasMissingField = requiredFields.some((field) => !String(input[field] ?? "").trim());

    if (hasMissingField) {
      return { ok: false, message: "Fill in all article fields before saving." };
    }

    const existingPost = input.slug
      ? userPosts.find((post) => post.slug === input.slug && (post.authorId === session.id || session.role === "admin"))
      : null;

    const nextPost = buildPublishedPost(input, session, existingPost);

    setUserPosts((current) => {
      if (existingPost) {
        return current.map((post) => (post.slug === existingPost.slug ? nextPost : normalizeArticle(post)));
      }

      return [nextPost, ...current.map(normalizeArticle)];
    });

    return { ok: true, slug: nextPost.slug, status: nextPost.status };
  };

  const publishArticle = saveArticle;

  const updateArticle = (slug, updates = {}) => {
    if (!session) {
      return { ok: false, message: "You need to sign in before updating articles." };
    }

    const target = userPosts.find((article) => article.slug === slug);

    if (!target) {
      return { ok: false, message: "Article not found." };
    }

    if (target.authorId !== session.id && session.role !== "admin") {
      return { ok: false, message: "You can only edit your own articles." };
    }

    setUserPosts((current) =>
      current.map((article) =>
        article.slug === slug
          ? normalizeArticle({
              ...article,
              ...updates,
              updatedAtISO: new Date().toISOString(),
            })
          : normalizeArticle(article)
      )
    );

    return { ok: true };
  };

  const approveArticle = (slug) => {
    if (!session || session.role !== "admin") {
      return { ok: false, message: "Admin access required." };
    }

    const result = updateArticle(slug, {
      status: "published",
      publishedAtISO: new Date().toISOString(),
      publishedAt: formatPublishedDate(),
      reviewNote: "",
    });

    if (result.ok) {
      const article = allArticles.find((a) => a.slug === slug);
      if (article && article.email) {
        sendApprovalEmail(article.email, article.author, article.title, "approved", "").catch(console.error);
      }
    }

    return result;
  };

  const rejectArticle = (slug, note = "") => {
    if (!session || session.role !== "admin") {
      return { ok: false, message: "Admin access required." };
    }

    const result = updateArticle(slug, {
      status: "rejected",
      reviewNote: note.trim(),
    });

    if (result.ok) {
      const article = allArticles.find((a) => a.slug === slug);
      if (article && article.email) {
        sendApprovalEmail(article.email, article.author, article.title, "rejected", note).catch(console.error);
      }
    }

    return result;
  };

  const setUserRole = (userId, role) => {
    if (!session || session.role !== "admin") {
      return { ok: false, message: "Admin access required." };
    }

    setUsers((current) =>
      current.map((user) =>
        user.id === userId
          ? {
              ...normalizeUser(user),
              role,
            }
          : normalizeUser(user)
      )
    );

    if (session.id === userId) {
      setSession((current) => (current ? { ...current, role } : current));
    }

    return { ok: true };
  };

  const registerArticleView = (slug) => {
    setUserPosts((current) =>
      current.map((article) =>
        article.slug === slug
          ? {
              ...normalizeArticle(article),
              viewCount: (article.viewCount ?? 0) + 1,
            }
          : normalizeArticle(article)
      )
    );
  };

  const publicGetArticle = (slug) => articles.find((article) => article.slug === slug) ?? null;
  const getArticle = (slug, includeHidden = false) => (includeHidden ? allArticles.find((article) => article.slug === slug) ?? null : publicGetArticle(slug));

  const myArticles = useMemo(() => {
    if (!session) {
      return [];
    }

    return allArticles.filter((article) => article.authorId === session.id || article.author === session.name);
  }, [allArticles, session]);

  const pendingArticles = useMemo(() => allArticles.filter((article) => article.status === "pending"), [allArticles]);
  const draftArticles = useMemo(() => allArticles.filter((article) => article.status === "draft"), [allArticles]);
  const scheduledArticles = useMemo(() => allArticles.filter((article) => article.status === "scheduled"), [allArticles]);
  const rejectedArticles = useMemo(() => allArticles.filter((article) => article.status === "rejected"), [allArticles]);

  const value = {
    articles,
    allArticles,
    featuredArticle,
    communityStats: stats,
    currentUser: session,
    signup,
    login,
    sendVerificationCode,
    verifyCurrentUser,
    logout,
    saveArticle,
    publishArticle,
    updateArticle,
    approveArticle,
    rejectArticle,
    setUserRole,
    registerArticleView,
    getArticle,
    myArticles,
    pendingArticles,
    draftArticles,
    scheduledArticles,
    rejectedArticles,
  };

  return <CommunityContext.Provider value={value}>{children}</CommunityContext.Provider>;
}

export function useCommunity() {
  const context = useContext(CommunityContext);

  if (!context) {
    throw new Error("useCommunity must be used within a CommunityProvider");
  }

  return context;
}
