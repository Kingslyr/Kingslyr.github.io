import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Seo from "./Seo";
import { useCommunity } from "../context/CommunityContext";

const initialAuth = { name: "", email: "", phone: "", password: "" };
const initialArticle = {
  title: "",
  category: "EIA",
  type: "Blog",
  readTime: "5 min read",
  excerpt: "",
  body: "",
  takeaways: "",
  featured: false,
};

export default function CommunityManagePage() {
  const {
    currentUser,
    signup,
    login,
    sendVerificationCode,
    verifyCurrentUser,
    logout,
    publishArticle,
    myArticles,
  } = useCommunity();

  const [mode, setMode] = useState("login");
  const [authForm, setAuthForm] = useState(initialAuth);
  const [verificationCode, setVerificationCode] = useState("");
  const [articleForm, setArticleForm] = useState(initialArticle);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const authTitle = mode === "login" ? "Sign in to post" : "Create your community account";
  const publishedCount = useMemo(() => myArticles.length, [myArticles.length]);

  const handleAuthChange = (event) => {
    const { name, value } = event.target;
    setAuthForm((current) => ({ ...current, [name]: value }));
  };

  const handleArticleChange = (event) => {
    const { name, value, type, checked } = event.target;
    setArticleForm((current) => ({ ...current, [name]: type === "checkbox" ? checked : value }));
  };

  const handleAuthSubmit = (event) => {
    event.preventDefault();
    setNotice("");
    setError("");

    const result =
      mode === "login"
        ? login({ identity: authForm.email || authForm.phone, password: authForm.password })
        : signup(authForm);

    if (!result.ok) {
      setError(result.message);
      return;
    }

    setAuthForm(initialAuth);

    if (result.verificationRequired) {
      setNotice(
        `Account created! Check your ${result.verificationMethod} for the verification code.`
      );
    } else {
      setNotice("Signed in successfully.");
    }
  };

  const handleSendCode = () => {
    setNotice("");
    setError("");

    const result = sendVerificationCode();

    if (!result.ok) {
      setError(result.message);
      return;
    }

    setNotice(
      `Verification code sent to ${session.verificationTarget}. Check your ${session.verificationMethod} for the 6-digit code.`
    );
  };

  const handleVerifySubmit = (event) => {
    event.preventDefault();
    setNotice("");
    setError("");

    const result = verifyCurrentUser(verificationCode);

    if (!result.ok) {
      setError(result.message);
      return;
    }

    setVerificationCode("");
    setNotice("Account verified successfully. You can now publish articles.");
  };

  const handleArticleSubmit = (event) => {
    event.preventDefault();
    setNotice("");
    setError("");

    const result = publishArticle(articleForm);

    if (!result.ok) {
      setError(result.message);
      return;
    }

    setArticleForm(initialArticle);
    setNotice("Article published successfully and is now live on the Community page.");
  };

  if (!currentUser) {
    return (
      <>
        <Seo
          title="Community Account Access | EnviroCore"
          description="Create a community account and verify via email or phone to publish blogs and articles on EnviroCore."
          canonicalPath="/community/manage"
        />
        <section className="mx-auto w-full max-w-6xl px-6 pb-24 pt-10">
          <div className="grid gap-6 lg:grid-cols-[0.95fr_1.05fr]">
            <div className="rounded-3xl border border-white/20 bg-white/10 p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)] backdrop-blur-2xl md:p-10">
              <p className="text-xs tracking-[0.3em] text-emerald-300/80">COMMUNITY PUBLISHING</p>
              <h1 className="mt-3 text-3xl font-semibold text-white md:text-5xl">Anyone can post after account verification</h1>
              <p className="mt-4 text-sm leading-7 text-white/75 md:text-base">
                Community members can create an account and publish content, but posting is unlocked only after verifying identity through email or phone number.
              </p>
              <div className="mt-8 space-y-3 text-sm text-white/80">
                <p className="rounded-xl border border-white/15 bg-black/35 px-4 py-3">1. Sign up with email or phone.</p>
                <p className="rounded-xl border border-white/15 bg-black/35 px-4 py-3">2. Verify with one-time code.</p>
                <p className="rounded-xl border border-white/15 bg-black/35 px-4 py-3">3. Publish blogs and articles publicly.</p>
              </div>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link to="/community" className="rounded-full border border-white/25 bg-white/5 px-5 py-2.5 text-sm text-white transition hover:bg-white/10">
                  Back to Community
                </Link>
              </div>
            </div>

            <div className="rounded-3xl border border-white/20 bg-black/35 p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)] backdrop-blur-2xl md:p-10">
              <div className="flex gap-2 rounded-full border border-white/15 bg-white/5 p-1 text-sm">
                <button
                  type="button"
                  onClick={() => setMode("login")}
                  className={`flex-1 rounded-full px-4 py-2 transition ${mode === "login" ? "bg-emerald-400 text-black" : "text-white/75"}`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => setMode("signup")}
                  className={`flex-1 rounded-full px-4 py-2 transition ${mode === "signup" ? "bg-emerald-400 text-black" : "text-white/75"}`}
                >
                  Sign Up
                </button>
              </div>

              <h2 className="mt-6 text-2xl font-semibold text-white">{authTitle}</h2>
              <form className="mt-6 space-y-4" onSubmit={handleAuthSubmit}>
                {mode === "signup" ? (
                  <input
                    name="name"
                    value={authForm.name}
                    onChange={handleAuthChange}
                    placeholder="Display name"
                    required
                    className="w-full rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
                  />
                ) : null}

                <input
                  name="email"
                  type="email"
                  value={authForm.email}
                  onChange={handleAuthChange}
                  placeholder={mode === "login" ? "Email or leave blank" : "Email (optional if phone is provided)"}
                  className="w-full rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
                />

                <input
                  name="phone"
                  value={authForm.phone}
                  onChange={handleAuthChange}
                  placeholder={mode === "login" ? "Phone or leave blank" : "Phone number (optional if email is provided)"}
                  className="w-full rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
                />

                <input
                  name="password"
                  type="password"
                  value={authForm.password}
                  onChange={handleAuthChange}
                  placeholder="Password"
                  required
                  className="w-full rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
                />

                {error ? <p className="text-sm text-rose-300">{error}</p> : null}
                {notice ? <p className="text-sm text-emerald-300">{notice}</p> : null}

                <button type="submit" className="w-full rounded-xl bg-emerald-400 px-6 py-3 text-sm font-semibold text-black transition hover:bg-emerald-300">
                  {mode === "login" ? "Sign In" : "Create Account"}
                </button>
              </form>
            </div>
          </div>
        </section>
      </>
    );
  }

  return (
    <>
      <Seo
        title="Community Publishing Dashboard | EnviroCore"
        description="Publish blogs and articles to the EnviroCore Community page from your verified community account."
        canonicalPath="/community/manage"
      />
      <section className="mx-auto w-full max-w-6xl px-6 pb-24 pt-10">
        <div className="grid gap-6 lg:grid-cols-[1.15fr_0.85fr] lg:items-start">
          <div className="rounded-3xl border border-white/20 bg-white/10 p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)] backdrop-blur-2xl md:p-10">
            <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <p className="text-xs tracking-[0.3em] text-emerald-300/80">COMMUNITY WRITER DASHBOARD</p>
                <h1 className="mt-3 text-3xl font-semibold text-white md:text-5xl">Publish to Community</h1>
              </div>
              <button
                type="button"
                onClick={logout}
                className="rounded-full border border-white/20 bg-white/5 px-4 py-2 text-xs font-semibold tracking-[0.12em] text-white transition hover:bg-white/10"
              >
                LOG OUT
              </button>
            </div>

            <p className="mt-4 text-sm text-white/75 md:text-base">
              Signed in as <span className="font-semibold text-white">{currentUser.name}</span>. You have published {publishedCount} article{publishedCount === 1 ? "" : "s"}.
            </p>

            {!currentUser.verified ? (
              <div className="mt-6 rounded-2xl border border-amber-300/30 bg-amber-400/10 p-5">
                <p className="text-sm font-semibold text-white">Account verification required before posting</p>
                <p className="mt-2 text-sm text-white/75">
                  Verify your account via {currentUser.verificationMethod} ({currentUser.verificationTarget}) to unlock publishing.
                </p>
                <div className="mt-4 flex flex-wrap gap-3">
                  <button
                    type="button"
                    onClick={handleSendCode}
                    className="rounded-full border border-white/25 bg-white/5 px-5 py-2 text-sm text-white transition hover:bg-white/10"
                  >
                    Send Verification Code
                  </button>
                </div>
                <form onSubmit={handleVerifySubmit} className="mt-4 flex flex-col gap-3 sm:flex-row">
                  <input
                    value={verificationCode}
                    onChange={(event) => setVerificationCode(event.target.value)}
                    placeholder="Enter 6-digit code"
                    required
                    className="w-full rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
                  />
                  <button
                    type="submit"
                    className="rounded-xl bg-emerald-400 px-6 py-3 text-sm font-semibold text-black transition hover:bg-emerald-300"
                  >
                    Verify Account
                  </button>
                </form>
              </div>
            ) : null}

            <form className="mt-8 grid gap-4" onSubmit={handleArticleSubmit}>
              <div className="grid gap-4 md:grid-cols-2">
                <input
                  name="title"
                  value={articleForm.title}
                  onChange={handleArticleChange}
                  placeholder="Article title"
                  required
                  disabled={!currentUser.verified}
                  className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
                />
                <input
                  name="readTime"
                  value={articleForm.readTime}
                  onChange={handleArticleChange}
                  placeholder="Read time"
                  required
                  disabled={!currentUser.verified}
                  className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
                />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <select
                  name="category"
                  value={articleForm.category}
                  onChange={handleArticleChange}
                  disabled={!currentUser.verified}
                  className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white outline-none transition focus:border-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <option value="EIA">EIA</option>
                  <option value="IEE">IEE</option>
                  <option value="ESG">ESG</option>
                  <option value="Audit">Audit</option>
                </select>
                <select
                  name="type"
                  value={articleForm.type}
                  onChange={handleArticleChange}
                  disabled={!currentUser.verified}
                  className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white outline-none transition focus:border-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  <option value="Blog">Blog</option>
                  <option value="Article">Article</option>
                </select>
              </div>

              <textarea
                name="excerpt"
                value={articleForm.excerpt}
                onChange={handleArticleChange}
                placeholder="Short excerpt for the article card"
                rows={3}
                required
                disabled={!currentUser.verified}
                className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
              />

              <textarea
                name="body"
                value={articleForm.body}
                onChange={handleArticleChange}
                placeholder="Write the article body. Separate paragraphs with a blank line."
                rows={10}
                required
                disabled={!currentUser.verified}
                className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
              />

              <textarea
                name="takeaways"
                value={articleForm.takeaways}
                onChange={handleArticleChange}
                placeholder="Key takeaways, one per line"
                rows={4}
                required
                disabled={!currentUser.verified}
                className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
              />

              <label className="flex items-center gap-3 rounded-xl border border-white/15 bg-black/25 px-4 py-3 text-sm text-white/80">
                <input
                  type="checkbox"
                  name="featured"
                  checked={articleForm.featured}
                  onChange={handleArticleChange}
                  disabled={!currentUser.verified}
                  className="h-4 w-4 rounded border-white/30 bg-black/35"
                />
                Mark as featured article
              </label>

              {error ? <p className="text-sm text-rose-300">{error}</p> : null}
              {notice ? <p className="text-sm text-emerald-300">{notice}</p> : null}

              <div className="flex flex-wrap gap-3">
                <button
                  type="submit"
                  disabled={!currentUser.verified}
                  className="rounded-xl bg-emerald-400 px-6 py-3 text-sm font-semibold text-black transition hover:bg-emerald-300 disabled:cursor-not-allowed disabled:opacity-60"
                >
                  Publish Article
                </button>
                <Link to="/community" className="rounded-xl border border-white/20 bg-white/5 px-6 py-3 text-sm text-white transition hover:bg-white/10">
                  View Public Community
                </Link>
              </div>
            </form>
          </div>

          <aside className="space-y-5 lg:sticky lg:top-28">
            <div className="rounded-3xl border border-white/15 bg-black/35 p-5 backdrop-blur-xl">
              <p className="text-xs tracking-[0.3em] text-emerald-300/80">VERIFICATION POLICY</p>
              <h2 className="mt-3 text-2xl font-semibold text-white">Open posting with verified identity</h2>
              <div className="mt-4 space-y-3 text-sm text-white/75">
                <p className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">Any community member can sign up.</p>
                <p className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">Publishing unlocks only after email or phone verification.</p>
                <p className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">Verified authors can post instantly to the public feed.</p>
              </div>
            </div>

            <div className="rounded-3xl border border-white/15 bg-black/35 p-5 backdrop-blur-xl">
              <p className="text-xs tracking-[0.3em] text-emerald-300/80">YOUR LATEST POSTS</p>
              <div className="mt-4 space-y-3">
                {myArticles.length ? (
                  myArticles.slice(0, 4).map((article) => (
                    <div key={article.slug} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                      <p className="text-xs uppercase tracking-[0.15em] text-emerald-300/75">
                        {article.type} - {article.category}
                      </p>
                      <h3 className="mt-2 text-base font-semibold text-white">{article.title}</h3>
                      <p className="mt-2 text-sm text-white/70">{article.excerpt}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-white/70">You have not published anything yet.</p>
                )}
              </div>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
