import { useState } from "react";

const initialForm = {
  name: "",
  email: "",
  project: "",
  location: "",
  details: "",
};

export default function ProposalGenerator() {
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState("idle");
  const [feedback, setFeedback] = useState("");

  const handleChange = (event) => {
    const { name, value } = event.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setStatus("submitting");
    setFeedback("");

    try {
      const response = await fetch("https://formspree.io/f/mzdkbpep", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(form),
      });

      if (!response.ok) {
        throw new Error("Submission failed");
      }

      setStatus("success");
      setFeedback("Proposal request submitted successfully. Our team will contact you within 24 hours.");
      setForm(initialForm);
    } catch (error) {
      setStatus("error");
      setFeedback("Unable to submit right now. Please try again or contact us on WhatsApp.");
    }
  };

  return (
    <section className="mx-auto w-full max-w-6xl px-6 pb-24 pt-10">
      <div className="rounded-3xl border border-white/20 bg-black/35 p-6 shadow-[0_30px_90px_rgba(0,0,0,0.5)] backdrop-blur-2xl md:p-10">
        <p className="text-center text-xs tracking-[0.32em] text-emerald-300/80">LEAD CAPTURE SYSTEM</p>
        <h2 className="mt-3 text-center text-3xl font-semibold text-white md:text-4xl">Request Environmental Proposal</h2>
        <p className="mx-auto mt-3 max-w-2xl text-center text-sm text-white/75 md:text-base">
          Submit project details for EIA, IEE, ESG strategy, or environmental audit services and receive a tailored proposal.
        </p>

        <form onSubmit={handleSubmit} className="mx-auto mt-8 grid max-w-3xl gap-4">
          <div className="grid gap-4 md:grid-cols-2">
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
              placeholder="Client Name"
              required
              disabled={status === "submitting"}
              className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
            />
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              placeholder="Work Email"
              required
              disabled={status === "submitting"}
              className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
            />
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <input
              name="project"
              value={form.project}
              onChange={handleChange}
              placeholder="Project Type (EIA / IEE / ESG / Audit)"
              required
              disabled={status === "submitting"}
              className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
            />
            <input
              name="location"
              value={form.location}
              onChange={handleChange}
              placeholder="Project Location"
              required
              disabled={status === "submitting"}
              className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
            />
          </div>

          <textarea
            name="details"
            value={form.details}
            onChange={handleChange}
            placeholder="Brief scope, approval stage, expected timeline, and key challenges"
            rows={5}
            disabled={status === "submitting"}
            className="rounded-xl border border-white/25 bg-black/35 px-4 py-3 text-white placeholder:text-white/60 outline-none transition focus:border-emerald-300"
          />

          {feedback ? (
            <p className={`text-sm ${status === "success" ? "text-emerald-300" : "text-rose-300"}`}>
              {feedback}
            </p>
          ) : null}

          <button
            type="submit"
            disabled={status === "submitting"}
            className="rounded-xl bg-emerald-500 px-6 py-3 text-sm font-semibold text-black transition hover:bg-emerald-400"
          >
            {status === "submitting" ? "Submitting..." : "Submit Proposal Request"}
          </button>
        </form>
      </div>
    </section>
  );
}
