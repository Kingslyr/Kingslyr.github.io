import { Link } from "react-router-dom";
import { useCommunity } from "../context/CommunityContext";
import Seo from "./Seo";

function StatCard({ label, value }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
      <p className="text-xs uppercase tracking-[0.2em] text-emerald-300/70">{label}</p>
      <p className="mt-2 text-2xl font-semibold text-white">{value}</p>
    </div>
  );
}

export default function CommunityPage() {
  const { articles, featuredArticle, currentUser, communityStats } = useCommunity();
  const secondaryArticles = articles.filter((article) => article.slug !== featuredArticle?.slug);
  const spotlightArticles = secondaryArticles.slice(0, 4);

  return (
    <>
      <Seo
        title="Community Blogs and Articles | EnviroCore"
        description="Explore EnviroCore's community blogs and articles on EIA, IEE, ESG, environmental audit strategy, and verified community publishing."
        canonicalPath="/community"
      />
      <section className="mx-auto w-full max-w-7xl px-6 pb-24 pt-10">
        <div className="grid gap-6 lg:grid-cols-[1.45fr_0.75fr] lg:items-start">
          <div className="space-y-6">
            <div className="rounded-3xl border border-white/20 bg-white/10 p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)] backdrop-blur-2xl md:p-10">
              <p className="text-xs tracking-[0.3em] text-emerald-300/80">COMMUNITY HUB</p>
              <h1 className="mt-3 max-w-3xl text-3xl font-semibold leading-tight text-white md:text-5xl">
                Community publishing with editorial weight
              </h1>
              <p className="mt-4 max-w-2xl text-sm leading-7 text-white/75 md:text-base">
                Practical guidance on EIA, IEE, ESG, and environmental audits, plus a verified publishing workflow for community members.
              </p>

              <div className="mt-8 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                <StatCard label="Published" value={communityStats.publishedCount} />
                <StatCard label="Members" value={communityStats.users} />
                <StatCard label="Verified" value={communityStats.verifiedUsers} />
                <StatCard label="Views" value={communityStats.totalViews} />
              </div>

              <div className="mt-8 overflow-hidden rounded-[2rem] border border-emerald-200/20 bg-[linear-gradient(145deg,rgba(7,18,32,0.95),rgba(9,41,36,0.72))] p-6 md:p-8">
                <div className="flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.15em] text-emerald-300/80">
                  <span>{featuredArticle.type}</span>
                  <span>{featuredArticle.category}</span>
                  <span>{featuredArticle.readTime}</span>
                  <span>{featuredArticle.publishedAt}</span>
                </div>
                <h2 className="mt-4 max-w-2xl text-2xl font-semibold text-white md:text-4xl">{featuredArticle.title}</h2>
                <p className="mt-4 max-w-2xl text-sm leading-7 text-white/78 md:text-base">{featuredArticle.excerpt}</p>
                {featuredArticle.coverImage ? (
                  <div className="mt-6 overflow-hidden rounded-2xl border border-white/10">
                    <img src={featuredArticle.coverImage} alt={featuredArticle.title} className="h-56 w-full object-cover" />
                  </div>
                ) : null}
                <div className="mt-6 flex flex-wrap gap-3">
                  <Link
                    to={`/community/${featuredArticle.slug}`}
                    className="rounded-full bg-emerald-400 px-5 py-2.5 text-sm font-semibold text-black transition hover:bg-emerald-300"
                  >
                    Read Featured Article
                  </Link>
                  <Link
                    to="/community/manage"
                    className="rounded-full border border-white/25 bg-white/5 px-5 py-2.5 text-sm text-white transition hover:bg-white/10"
                  >
                    Write an Article
                  </Link>
                  <Link
                    to="/#proposal"
                    className="rounded-full border border-white/25 bg-white/5 px-5 py-2.5 text-sm text-white transition hover:bg-white/10"
                  >
                    Request Proposal
                  </Link>
                </div>
              </div>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              {spotlightArticles.map((article) => (
                <article key={article.slug} className="rounded-2xl border border-white/15 bg-black/35 p-5 transition hover:bg-white/10">
                  <div className="flex items-center justify-between text-xs uppercase tracking-[0.15em] text-emerald-300/80">
                    <span>{article.type}</span>
                    <span>{article.readTime}</span>
                  </div>
                  <h3 className="mt-3 text-xl font-semibold text-white">{article.title}</h3>
                  <p className="mt-3 text-sm leading-7 text-white/75">{article.excerpt}</p>
                  <Link
                    to={`/community/${article.slug}`}
                    className="mt-4 inline-flex text-xs font-semibold tracking-[0.14em] text-emerald-200 transition hover:text-emerald-100"
                  >
                    READ ARTICLE
                  </Link>
                </article>
              ))}
            </div>
          </div>

          <aside className="space-y-5 lg:sticky lg:top-28">
            <div className="rounded-3xl border border-white/15 bg-black/35 p-5 backdrop-blur-xl">
              <p className="text-xs tracking-[0.3em] text-emerald-300/80">EDITORIAL FOCUS</p>
              <h2 className="mt-3 text-2xl font-semibold text-white">Latest insights</h2>
              <div className="mt-4 space-y-3">
                {articles.map((article) => (
                  <Link
                    key={article.slug}
                    to={`/community/${article.slug}`}
                    className="block rounded-2xl border border-white/10 bg-white/5 p-4 transition hover:bg-white/10"
                  >
                    <p className="text-xs uppercase tracking-[0.15em] text-emerald-300/75">
                      {article.category} - {article.readTime}
                    </p>
                    <h3 className="mt-2 text-base font-semibold text-white">{article.title}</h3>
                    <p className="mt-2 text-sm text-white/70">{article.excerpt}</p>
                  </Link>
                ))}
              </div>
            </div>

            <div className="rounded-3xl border border-white/15 bg-black/35 p-5 backdrop-blur-xl">
              <p className="text-xs tracking-[0.3em] text-emerald-300/80">PUBLISHING ACCESS</p>
              <h2 className="mt-3 text-2xl font-semibold text-white">Verified authors can post</h2>
              <p className="mt-3 text-sm leading-7 text-white/75">
                {currentUser
                  ? `Signed in as ${currentUser.name}. ${currentUser.verified ? "Publishing is unlocked." : "Verify your account to post."}`
                  : "Create an account, verify via email or phone, and unlock publishing."}
              </p>
              <div className="mt-4 grid gap-3 text-sm text-white/75">
                <p className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">Open signup with verification gate.</p>
                <p className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">Drafts, scheduling, and review workflows for authors.</p>
                <p className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">Admin moderation for approvals and roles.</p>
              </div>
              <Link
                to="/community/manage"
                className="mt-4 inline-flex rounded-full bg-emerald-400 px-6 py-2.5 text-sm font-semibold text-black transition hover:bg-emerald-300"
              >
                Write an Article
              </Link>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}
