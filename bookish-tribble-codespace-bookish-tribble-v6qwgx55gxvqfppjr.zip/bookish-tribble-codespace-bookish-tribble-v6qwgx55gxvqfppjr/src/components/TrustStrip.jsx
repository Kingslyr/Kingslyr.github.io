const trustMetrics = [
  { value: "50+", label: "EIA / IEE Projects" },
  { value: "20+", label: "Audits and ESG Reports" },
  { value: "24h", label: "Initial Proposal Response" },
  { value: "Nationwide", label: "Pakistan Coverage" },
];

const sectors = ["Energy", "Infrastructure", "Industrial", "Real Estate", "Public Sector"];

export default function TrustStrip() {
  return (
    <section className="mx-auto mt-4 w-full max-w-6xl px-6" aria-label="Trust indicators">
      <div className="rounded-2xl border border-white/15 bg-black/35 p-4 backdrop-blur-xl md:p-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <p className="text-xs uppercase tracking-[0.28em] text-emerald-200/80">Trusted Across High-Impact Sectors</p>
          <div className="flex flex-wrap gap-2">
            {sectors.map((sector) => (
              <span
                key={sector}
                className="rounded-full border border-white/20 bg-white/5 px-3 py-1 text-[0.68rem] uppercase tracking-[0.14em] text-white/75"
              >
                {sector}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {trustMetrics.map((metric) => (
            <article key={metric.label} className="rounded-xl border border-white/15 bg-black/30 px-4 py-3">
              <p className="text-xl font-semibold text-white">{metric.value}</p>
              <p className="mt-1 text-xs uppercase tracking-[0.12em] text-white/65">{metric.label}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
