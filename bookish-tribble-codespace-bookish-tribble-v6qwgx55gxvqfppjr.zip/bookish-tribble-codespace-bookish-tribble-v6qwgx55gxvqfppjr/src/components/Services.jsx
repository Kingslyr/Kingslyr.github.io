import { Link } from "react-router-dom";
import { servicesData } from "../data/servicesData";

export default function Services() {
  return (
    <section className="rounded-3xl border border-white/20 bg-white/10 p-8 shadow-[0_30px_70px_rgba(0,0,0,0.4)] backdrop-blur-2xl md:p-10">
      <h2 className="text-center text-3xl font-semibold text-white md:text-4xl">Core Environmental Services</h2>
      <p className="mx-auto mt-4 max-w-3xl text-center text-white/80">
        We help developers, industries, and institutions secure approvals, maintain compliance, and strengthen ESG performance through field-based technical delivery.
      </p>

      <div className="mt-8 grid gap-4 md:grid-cols-2">
        {servicesData.map((item) => (
          <article key={item.title} className="rounded-2xl border border-white/20 bg-black/35 p-5 backdrop-blur-md transition hover:bg-white/10">
            <h3 className="text-lg font-semibold text-emerald-300">{item.title}</h3>
            <p className="mt-2 text-sm text-white/75">{item.summary}</p>
            <Link
              to={`/services/${item.slug}`}
              className="mt-4 inline-flex text-xs font-semibold tracking-[0.14em] text-emerald-200 transition hover:text-emerald-100"
            >
              VIEW SERVICE PAGE
            </Link>
          </article>
        ))}
      </div>
    </section>
  );
}
