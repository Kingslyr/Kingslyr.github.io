import { useEffect } from "react";

function upsertMeta(attribute, key, value) {
  let element = document.head.querySelector(`meta[${attribute}="${key}"]`);

  if (!element) {
    element = document.createElement("meta");
    element.setAttribute(attribute, key);
    document.head.appendChild(element);
  }

  element.setAttribute("content", value);
}

function upsertLink(rel, href) {
  let element = document.head.querySelector(`link[rel="${rel}"]`);

  if (!element) {
    element = document.createElement("link");
    element.setAttribute("rel", rel);
    document.head.appendChild(element);
  }

  element.setAttribute("href", href);
}

function removeSeoJsonLd() {
  document.querySelectorAll('script[data-seo-jsonld="true"]').forEach((element) => element.remove());
}

export default function Seo({
  title,
  description,
  canonicalPath,
  ogType = "website",
  ogImage = "https://envirocore-emc.me/assets/preview-image.png",
  robots = "index, follow",
  jsonLd,
  articleMeta,
}) {
  useEffect(() => {
    const canonicalUrl = `${window.location.origin}${canonicalPath ?? window.location.pathname}`;

    document.title = title;
    upsertMeta("name", "description", description);
    upsertMeta("name", "robots", robots);
    upsertMeta("property", "og:title", title);
    upsertMeta("property", "og:description", description);
    upsertMeta("property", "og:type", ogType);
    upsertMeta("property", "og:url", canonicalUrl);
    upsertMeta("property", "og:image", ogImage);
    upsertMeta("name", "twitter:title", title);
    upsertMeta("name", "twitter:description", description);
    upsertMeta("name", "twitter:image", ogImage);
    upsertMeta("name", "twitter:card", "summary_large_image");
    upsertLink("canonical", canonicalUrl);

    if (articleMeta) {
      Object.entries(articleMeta).forEach(([name, value]) => {
        upsertMeta("property", name, value);
      });
    }

    removeSeoJsonLd();

    if (jsonLd) {
      const script = document.createElement("script");
      script.type = "application/ld+json";
      script.setAttribute("data-seo-jsonld", "true");
      script.textContent = JSON.stringify(jsonLd);
      document.head.appendChild(script);
    }

    return () => {
      removeSeoJsonLd();
    };
  }, [title, description, canonicalPath, ogType, ogImage, robots, jsonLd, articleMeta]);

  return null;
}
