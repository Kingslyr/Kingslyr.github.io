import { Link } from "react-router-dom";
import { servicesData } from "../data/servicesData";

export default function ServicePages() {
  return (
    <section className="rounded-3xl border border-white/15 bg-white/5 p-6 shadow-[0_24px_75px_rgba(0,0,0,0.45)] backdrop-blur-xl md:p-10">
      <p className="text-center text-xs tracking-[0.32em] text-emerald-300/80">CONVERSION-OPTIMIZED SERVICE PAGES</p>
      <h2 className="mt-3 text-center text-3xl font-semibold text-white md:text-4xl">Detailed Service Solutions</h2>

      <div className="mt-8 grid gap-5 md:grid-cols-2">
        {servicesData.map((service) => (
          <article key={service.title} className="rounded-2xl border border-white/15 bg-black/30 p-5">
            <h3 className="text-xl font-semibold text-emerald-300">{service.title}</h3>
            <p className="mt-3 text-sm text-white/75">{service.intro}</p>

            <ul className="mt-4 space-y-2 text-sm text-white/80">
              {service.points.map((point) => (
                <li key={point}>- {point}</li>
              ))}
            </ul>

            <Link
              to={`/services/${service.slug}`}
              className="mt-5 inline-flex rounded-full border border-emerald-300/60 bg-emerald-300/10 px-5 py-2 text-xs font-semibold tracking-[0.12em] text-emerald-100 transition hover:bg-emerald-300/20"
            >
              OPEN SERVICE PAGE
            </Link>
          </article>
        ))}
      </div>
    </section>
  );
}
