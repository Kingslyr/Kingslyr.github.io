import { useMemo, useState } from "react";
import { Link, Navigate } from "react-router-dom";
import Seo from "./Seo";
import { useCommunity } from "../context/CommunityContext";

export default function CommunityAdminPage() {
  const { currentUser, approveArticle, rejectArticle, allArticles, communityStats, users } = useCommunity();
  const [activeTab, setActiveTab] = useState("pending");
  const [rejectNotes, setRejectNotes] = useState({});
  const [expandedArticle, setExpandedArticle] = useState(null);

  if (!currentUser || currentUser.role !== "admin") {
    return <Navigate to="/community" replace />;
  }

  const pendingArticles = useMemo(() => allArticles.filter((a) => a.status === "pending"), [allArticles]);
  const draftArticles = useMemo(() => allArticles.filter((a) => a.status === "draft"), [allArticles]);
  const publishedArticles = useMemo(() => allArticles.filter((a) => a.status === "published"), [allArticles]);
  const rejectedArticles = useMemo(() => allArticles.filter((a) => a.status === "rejected"), [allArticles]);
  const scheduledArticles = useMemo(() => allArticles.filter((a) => a.status === "scheduled"), [allArticles]);

  const handleApprove = (slug) => {
    const result = approveArticle(slug);
    if (result.ok) {
      setExpandedArticle(null);
    }
  };

  const handleReject = (slug) => {
    const result = rejectArticle(slug, rejectNotes[slug] || "");
    if (result.ok) {
      setRejectNotes((current) => {
        const next = { ...current };
        delete next[slug];
        return next;
      });
      setExpandedArticle(null);
    }
  };

  const tabs = [
    { key: "pending", label: "Pending Review", articles: pendingArticles, color: "amber" },
    { key: "published", label: "Published", articles: publishedArticles, color: "emerald" },
    { key: "scheduled", label: "Scheduled", articles: scheduledArticles, color: "blue" },
    { key: "draft", label: "Drafts", articles: draftArticles, color: "slate" },
    { key: "rejected", label: "Rejected", articles: rejectedArticles, color: "rose" },
  ];

  const currentTab = tabs.find((t) => t.key === activeTab);

  return (
    <>
      <Seo
        title="Community Admin | EnviroCore"
        description="Manage and moderate community content on EnviroCore."
        canonicalPath="/community/admin"
        robots="noindex, nofollow"
      />
      <section className="mx-auto w-full max-w-7xl px-6 pb-24 pt-10">
        <div className="rounded-3xl border border-white/20 bg-white/10 p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)] backdrop-blur-2xl md:p-10">
          <div className="flex items-center justify-between gap-4 border-b border-white/10 pb-4">
            <div>
              <p className="text-xs tracking-[0.3em] text-emerald-300/80">ADMIN DASHBOARD</p>
              <h1 className="mt-3 text-3xl font-semibold text-white md:text-4xl">Community Moderation</h1>
            </div>
            <Link
              to="/community"
              className="rounded-full border border-white/20 bg-white/5 px-4 py-2 text-sm text-white transition hover:bg-white/10"
            >
              Back
            </Link>
          </div>

          <div className="mt-8 grid gap-4 md:grid-cols-5">
            <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
              <p className="text-xs uppercase tracking-[0.2em] text-emerald-300/70">Total Users</p>
              <p className="mt-2 text-2xl font-semibold text-white">{communityStats.users}</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
              <p className="text-xs uppercase tracking-[0.2em] text-emerald-300/70">Verified</p>
              <p className="mt-2 text-2xl font-semibold text-white">{communityStats.verifiedUsers}</p>
            </div>
            <div className="rounded-2xl border border-amber-400/20 bg-amber-400/10 p-4">
              <p className="text-xs uppercase tracking-[0.2em] text-amber-300/70">Pending</p>
              <p className="mt-2 text-2xl font-semibold text-white">{communityStats.pendingCount}</p>
            </div>
            <div className="rounded-2xl border border-emerald-400/20 bg-emerald-400/10 p-4">
              <p className="text-xs uppercase tracking-[0.2em] text-emerald-300/70">Published</p>
              <p className="mt-2 text-2xl font-semibold text-white">{communityStats.publishedCount}</p>
            </div>
            <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
              <p className="text-xs uppercase tracking-[0.2em] text-slate-300/70">Total Views</p>
              <p className="mt-2 text-2xl font-semibold text-white">{communityStats.totalViews}</p>
            </div>
          </div>

          <div className="mt-8 space-y-6">
            <div className="flex gap-2 overflow-x-auto rounded-full border border-white/15 bg-black/35 p-1">
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key)}
                  className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-semibold transition ${
                    activeTab === tab.key
                      ? `bg-${tab.color}-400 text-black`
                      : `text-white/75 hover:text-white`
                  }`}
                >
                  {tab.label} ({tab.articles.length})
                </button>
              ))}
            </div>

            <div className="space-y-4">
              {currentTab.articles.length === 0 ? (
                <div className="rounded-2xl border border-white/10 bg-black/20 p-8 text-center">
                  <p className="text-sm text-white/70">No articles in this category</p>
                </div>
              ) : (
                currentTab.articles.map((article) => (
                  <div
                    key={article.slug}
                    className={`rounded-2xl border transition ${
                      expandedArticle === article.slug
                        ? "border-white/30 bg-white/15"
                        : "border-white/10 bg-black/30 hover:bg-black/50"
                    } p-5`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-[0.15em]">
                          <span className="text-emerald-300/80">{article.type}</span>
                          <span className="text-slate-400">{article.category}</span>
                          <span className="text-white/60">{article.readTime}</span>
                          <span className="text-white/50">{article.publishedAt}</span>
                        </div>
                        <h3 className="mt-2 text-xl font-semibold text-white">{article.title}</h3>
                        <p className="mt-2 text-sm text-white/70">
                          By <span className="font-semibold">{article.author}</span>
                        </p>
                        <p className="mt-2 text-sm leading-6 text-white/75">{article.excerpt}</p>

                        {expandedArticle === article.slug ? (
                          <div className="mt-4 space-y-4 rounded-xl border border-white/10 bg-white/5 p-4">
                            <div>
                              <p className="text-xs uppercase tracking-[0.15em] text-white/60">Full Content</p>
                              <div className="mt-2 max-h-64 overflow-y-auto text-sm text-white/80">
                                {article.sections.map((section) => (
                                  <div key={section.heading} className="mb-3">
                                    <h4 className="font-semibold text-white">{section.heading}</h4>
                                    <p className="mt-1 text-white/70">{section.body}</p>
                                  </div>
                                ))}
                              </div>
                            </div>

                            {article.status === "pending" ? (
                              <div className="space-y-3 border-t border-white/10 pt-3">
                                <textarea
                                  value={rejectNotes[article.slug] || ""}
                                  onChange={(e) =>
                                    setRejectNotes((current) => ({
                                      ...current,
                                      [article.slug]: e.target.value,
                                    }))
                                  }
                                  placeholder="Optional rejection note (sent to author)"
                                  className="w-full rounded-lg border border-white/20 bg-black/50 px-3 py-2 text-xs text-white placeholder:text-white/50 outline-none focus:border-emerald-300"
                                  rows={3}
                                />
                                <div className="flex gap-3">
                                  <button
                                    onClick={() => handleApprove(article.slug)}
                                    className="flex-1 rounded-lg bg-emerald-400 px-4 py-2 text-sm font-semibold text-black transition hover:bg-emerald-300"
                                  >
                                    ✓ Approve & Publish
                                  </button>
                                  <button
                                    onClick={() => handleReject(article.slug)}
                                    className="flex-1 rounded-lg bg-rose-400 px-4 py-2 text-sm font-semibold text-black transition hover:bg-rose-300"
                                  >
                                    ✕ Reject
                                  </button>
                                </div>
                              </div>
                            ) : null}

                            {article.status === "rejected" && article.reviewNote ? (
                              <div className="rounded-lg border border-rose-300/30 bg-rose-400/10 p-3">
                                <p className="text-xs font-semibold text-rose-200">Rejection Note:</p>
                                <p className="mt-1 text-sm text-rose-100/80">{article.reviewNote}</p>
                              </div>
                            ) : null}

                            <button
                              onClick={() => setExpandedArticle(null)}
                              className="mt-3 w-full rounded-lg border border-white/10 bg-white/5 px-4 py-2 text-sm text-white transition hover:bg-white/10"
                            >
                              Close
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => setExpandedArticle(article.slug)}
                            className="mt-3 text-xs font-semibold tracking-[0.14em] text-emerald-200 transition hover:text-emerald-100"
                          >
                            VIEW DETAILS
                          </button>
                        )}
                      </div>

                      <div className="flex-shrink-0 text-right text-xs text-white/50">{article.viewCount} views</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
