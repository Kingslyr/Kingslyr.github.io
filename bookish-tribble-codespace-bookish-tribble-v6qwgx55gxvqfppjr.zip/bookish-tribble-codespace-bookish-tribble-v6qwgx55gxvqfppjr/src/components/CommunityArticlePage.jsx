import { Link, Navigate, useParams } from "react-router-dom";
import { useCommunity } from "../context/CommunityContext";
import Seo from "./Seo";

export default function CommunityArticlePage() {
  const { slug } = useParams();
  const { getArticle, articles } = useCommunity();
  const article = getArticle(slug);

  if (!article) {
    return <Navigate to="/community" replace />;
  }

  const relatedArticles = articles.filter((item) => item.slug !== article.slug).slice(0, 3);

  return (
    <>
      <Seo
        title={`${article.title} | EnviroCore Community`}
        description={article.excerpt}
        canonicalPath={`/community/${article.slug}`}
        ogType="article"
        articleMeta={{
          "article:tag": article.category,
          "article:section": article.category,
          "article:published_time": "2026-04-28",
          "article:author": "Engr. Saeed Ur Rehman Samoo",
        }}
        jsonLd={{
          "@context": "https://schema.org",
          "@type": "Article",
          headline: article.title,
          description: article.excerpt,
          author: {
            "@type": "Person",
            name: "Engr. Saeed Ur Rehman Samoo",
          },
          publisher: {
            "@type": "Organization",
            name: "EnviroCore",
            logo: {
              "@type": "ImageObject",
              url: "https://envirocore-emc.me/logo512.png",
            },
          },
          datePublished: "2026-04-28",
          mainEntityOfPage: {
            "@type": "WebPage",
            "@id": `https://envirocore-emc.me/community/${article.slug}`,
          },
        }}
      />
      <section className="mx-auto w-full max-w-7xl px-6 pb-24 pt-10">
      <div className="grid gap-6 lg:grid-cols-[1.4fr_0.8fr] lg:items-start">
        <article className="rounded-3xl border border-white/20 bg-white/10 p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)] backdrop-blur-2xl md:p-10">
          <div className="flex flex-wrap items-center gap-3 text-xs uppercase tracking-[0.15em] text-emerald-300/80">
            <span>{article.type}</span>
            <span>{article.category}</span>
            <span>{article.readTime}</span>
            <span>{article.publishedAt}</span>
            {article.author ? <span>{article.author}</span> : null}
          </div>

          <h1 className="mt-4 text-3xl font-semibold leading-tight text-white md:text-5xl">{article.title}</h1>
          <p className="mt-5 max-w-3xl text-sm text-white/75 md:text-base">{article.excerpt}</p>

          <div className="mt-8 space-y-8">
            {article.sections.map((section) => (
              <section key={section.heading}>
                <h2 className="text-xl font-semibold text-emerald-300">{section.heading}</h2>
                <p className="mt-3 text-sm leading-7 text-white/80 md:text-base">{section.body}</p>
              </section>
            ))}
          </div>

          <div className="mt-10 rounded-2xl border border-emerald-200/20 bg-emerald-400/10 p-5">
            <p className="text-sm font-semibold text-white">Key takeaways</p>
            <ul className="mt-4 space-y-2 text-sm text-white/80">
              {article.takeaways.map((item) => (
                <li key={item}>- {item}</li>
              ))}
            </ul>
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link
              to="/community"
              className="rounded-full border border-white/25 bg-white/5 px-5 py-2.5 text-sm text-white transition hover:bg-white/10"
            >
              Back to Community
            </Link>
            <Link
              to="/#proposal"
              className="rounded-full bg-emerald-400 px-5 py-2.5 text-sm font-semibold text-black transition hover:bg-emerald-300"
            >
              Request Proposal
            </Link>
          </div>
        </article>

        <aside className="space-y-5 lg:sticky lg:top-28">
          <div className="rounded-3xl border border-white/15 bg-black/35 p-5 backdrop-blur-xl">
            <p className="text-xs tracking-[0.3em] text-emerald-300/80">EDITORIAL NOTES</p>
            <h2 className="mt-3 text-2xl font-semibold text-white">Why this article matters</h2>
            <p className="mt-3 text-sm leading-7 text-white/75">
              These articles are written as practical field guides for clients who need approvals, compliance clarity, and stronger environmental management decisions.
            </p>
          </div>

          <div className="rounded-3xl border border-white/15 bg-black/35 p-5 backdrop-blur-xl">
            <p className="text-xs tracking-[0.3em] text-emerald-300/80">MORE ARTICLES</p>
            <div className="mt-4 space-y-3">
              {relatedArticles.map((item) => (
                <Link
                  key={item.slug}
                  to={`/community/${item.slug}`}
                  className="block rounded-2xl border border-white/10 bg-white/5 p-4 transition hover:bg-white/10"
                >
                  <p className="text-xs uppercase tracking-[0.15em] text-emerald-300/75">
                    {item.type} - {item.category}
                  </p>
                  <h3 className="mt-2 text-base font-semibold text-white">{item.title}</h3>
                  <p className="mt-2 text-sm text-white/70">{item.excerpt}</p>
                </Link>
              ))}
            </div>
          </div>
        </aside>
      </div>
      </section>
    </>
  );
}
