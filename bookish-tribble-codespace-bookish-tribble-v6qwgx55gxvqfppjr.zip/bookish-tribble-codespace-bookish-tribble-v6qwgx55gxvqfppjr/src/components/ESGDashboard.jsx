import { useEffect, useState } from "react";

const KPI_TARGETS = [
  { label: "EIA", value: 98 },
  { label: "IEE", value: 97 },
  { label: "ESG", value: 96 },
];

const trendData = [44, 52, 58, 62, 71, 79, 86, 92, 98];

export default function ESGDashboard() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((current) => (current < 98 ? current + 1 : 98));
    }, 20);

    return () => clearInterval(timer);
  }, []);

  return (
    <section className="rounded-3xl border border-white/15 bg-[linear-gradient(155deg,rgba(5,12,24,0.9),rgba(7,35,31,0.7),rgba(4,10,22,0.95))] p-6 shadow-[0_26px_85px_rgba(0,0,0,0.5)] backdrop-blur-xl md:p-10">
      <div className="mx-auto max-w-3xl text-center">
        <p className="text-xs tracking-[0.32em] text-emerald-300/80">ENVIRONMENTAL INTELLIGENCE</p>
        <h2 className="mt-3 text-3xl font-semibold text-white md:text-4xl">Project Readiness Index (ESG Performance)</h2>
        <p className="mx-auto mt-4 max-w-2xl text-sm text-white/75 md:text-base">
          Monitor environmental documentation, compliance status, and sustainability performance in one executive snapshot.
        </p>

        <div className="mt-8 overflow-hidden rounded-full border border-emerald-200/35 bg-black/45 p-1.5">
          <div
            className="h-4 rounded-full bg-gradient-to-r from-emerald-300 via-cyan-300 to-emerald-500 transition-[width] duration-300"
            style={{ width: `${progress}%` }}
            aria-hidden="true"
          />
        </div>

        <p className="mt-4 text-sm text-white/80 md:text-base">
          Overall Environmental Readiness: <span className="font-semibold text-emerald-300">{progress}%</span>
        </p>

        <div className="mt-8 grid gap-3 sm:grid-cols-3">
          {KPI_TARGETS.map((item) => (
            <article key={item.label} className="rounded-xl border border-white/15 bg-black/35 px-4 py-3 text-center">
              <p className="text-xs tracking-[0.2em] text-emerald-300/80">{item.label}</p>
              <p className="mt-1 text-lg font-semibold text-white">{Math.min(progress, item.value)}%</p>
            </article>
          ))}
        </div>

        <div className="mt-8 rounded-2xl border border-white/15 bg-black/35 p-4 text-left">
          <p className="text-xs tracking-[0.2em] text-emerald-300/80">READINESS TREND</p>
          <div className="mt-4 flex h-28 items-end gap-2">
            {trendData.map((value, index) => (
              <div key={value} className="flex-1">
                <div
                  className="rounded-t-md bg-gradient-to-t from-emerald-500/60 to-cyan-300/90 transition-[height] duration-500"
                  style={{ height: `${Math.min(value, progress)}%` }}
                  aria-label={`Trend point ${index + 1}`}
                />
              </div>
            ))}
          </div>
          <div className="mt-3 flex justify-between text-[0.68rem] uppercase tracking-[0.16em] text-white/55">
            <span>Q1</span>
            <span>Q2</span>
            <span>Q3</span>
            <span>Q4</span>
          </div>
        </div>
      </div>
    </section>
  );
}
