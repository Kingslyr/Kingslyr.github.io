import { Navigate, useParams } from "react-router-dom";
import { getServiceBySlug } from "../data/servicesData";

export default function ServiceDetailPage() {
  const { slug } = useParams();
  const service = getServiceBySlug(slug);

  if (!service) {
    return <Navigate to="/" replace />;
  }

  return (
    <section className="mx-auto w-full max-w-6xl px-6 pb-20 pt-10">
      <div className="rounded-3xl border border-white/20 bg-white/10 p-8 shadow-[0_30px_70px_rgba(0,0,0,0.4)] backdrop-blur-2xl md:p-12">
        <p className="text-xs tracking-[0.3em] text-emerald-300/80">SERVICE DETAIL</p>
        <h1 className="mt-3 text-3xl font-semibold text-white md:text-5xl">{service.title}</h1>
        <p className="mt-5 max-w-3xl text-sm text-white/80 md:text-base">{service.intro}</p>

        <div className="mt-8 grid gap-3 text-sm text-white/80">
          {service.points.map((point) => (
            <p key={point} className="rounded-xl border border-white/15 bg-black/35 px-4 py-3">
              {point}
            </p>
          ))}
        </div>

        <a
          href="/#proposal"
          className="mt-8 inline-flex rounded-full bg-emerald-500 px-6 py-3 text-sm font-semibold text-black transition hover:bg-emerald-400"
        >
          Request {service.slug.toUpperCase()} Proposal
        </a>
      </div>
    </section>
  );
}
