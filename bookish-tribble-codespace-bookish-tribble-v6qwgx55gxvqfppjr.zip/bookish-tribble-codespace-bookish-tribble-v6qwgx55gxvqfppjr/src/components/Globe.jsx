import { useMemo, useRef, useEffect } from "react";
import { useFrame, useLoader, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { PMREMGenerator, TextureLoader } from "three";

export default function Globe() {
  const ref = useRef();
  const nodeRefs = useRef([]);
  const { gl, scene } = useThree();

  const earthTexture = useLoader(
    TextureLoader,
    "https://raw.githubusercontent.com/jeromeetienne/threex.planets/master/images/earthmap1k.jpg"
  );
  const earthSpec = useLoader(
    TextureLoader,
    "https://raw.githubusercontent.com/jeromeetienne/threex.planets/master/images/earthspec1k.jpg"
  );
  const earthNormal = useLoader(
    TextureLoader,
    "https://raw.githubusercontent.com/jeromeetienne/threex.planets/master/images/earthbump1k.jpg"
  );

  useEffect(() => {
    [earthTexture, earthSpec, earthNormal].forEach((t) => {
      if (t) {
        t.colorSpace = THREE.SRGBColorSpace;
        t.anisotropy = Math.min(16, gl.capabilities.getMaxAnisotropy());
      }
    });

    // Try to load a bright equirectangular environment for more realistic lighting.
    const envUrl = "https://raw.githubusercontent.com/pmndrs/drei-assets/main/hdri/venice_sunset_1k.jpg";
    let pmremGenerator;
    const loader = new TextureLoader();
    loader.crossOrigin = "anonymous";
    loader.load(
      envUrl,
      (tex) => {
        try {
          pmremGenerator = new PMREMGenerator(gl);
          pmremGenerator.compileEquirectangularShader();
          const envMap = pmremGenerator.fromEquirectangular(tex).texture;
          scene.environment = envMap;
          tex.dispose();
        } catch (err) {
          console.warn("Failed to apply env map, falling back to lights:", err);
        }
      },
      undefined,
      () => {
        // on error: leave fallback lighting
        console.warn("HDRI env load failed; using fallback lights");
      }
    );

    return () => {
      if (pmremGenerator) pmremGenerator.dispose();
      if (scene.environment) {
        try {
          scene.environment.dispose();
        } catch {}
      }
    };
  }, [earthTexture, earthNormal, earthSpec, gl, scene]);

  const network = useMemo(() => {
    const latLngToVec3 = (lat, lng, radius = 2.06) => {
      const phi = (90 - lat) * (Math.PI / 180);
      const theta = (lng + 180) * (Math.PI / 180);
      const x = -(radius * Math.sin(phi) * Math.cos(theta));
      const y = radius * Math.cos(phi);
      const z = radius * Math.sin(phi) * Math.sin(theta);
      return [x, y, z];
    };

    const nodeLatLng = [
      [24, 67],
      [35, -120],
      [-23, -46],
      [1, 103],
      [19, 72],
      [51, 0],
      [-1, 36],
    ];

    const links = [
      [0, 4],
      [4, 3],
      [3, 6],
      [6, 5],
      [5, 1],
      [0, 2],
      [2, 1],
    ];

    const nodes = nodeLatLng.map(([lat, lng]) => latLngToVec3(lat, lng));
    const linkPositions = links.map(([a, b]) => [...nodes[a], ...nodes[b]]);

    return { nodes, linkPositions };
  }, []);

  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.y += 0.001;
      ref.current.rotation.x = Math.sin(clock.elapsedTime * 0.12) * 0.06;
    }

    const t = clock.getElapsedTime();
    nodeRefs.current.forEach((node, index) => {
      if (!node) {
        return;
      }
      const pulse = 1 + Math.sin(t * 2.2 + index) * 0.35;
      node.scale.setScalar(pulse);
    });
  });

  return (
    <group ref={ref}>
      <mesh>
        <sphereGeometry args={[2, 96, 96]} />
        <meshStandardMaterial
          map={earthTexture}
          normalMap={earthNormal}
          metalnessMap={earthSpec}
          metalness={0.3}
          roughness={0.5}
          envMapIntensity={1.2}
          emissive="#0066ff"
          emissiveIntensity={0.15}
          toneMapped={true}
        />
      </mesh>

      {/* Bright directional sun light */}
      <directionalLight position={[3, 2, 1.5]} intensity={2.5} color="#ffffff" />
      
      {/* Fill light for blue tones */}
      <directionalLight position={[-2, -1, -2]} intensity={1.8} color="#66ccff" />
      
      {/* Hemisphere light for overall brightness */}
      <hemisphereLight intensity={1.5} groundColor="#1a6b9f" skyColor="#87CEEB" />
      
      {/* Ambient light boost */}
      <ambientLight intensity={0.8} color="#ffffff" />

      {network.linkPositions.map((linePosition, index) => (
        <line key={`line-${index}`}>
          <bufferGeometry>
            <bufferAttribute
              attach="attributes-position"
              count={2}
              array={new Float32Array(linePosition)}
              itemSize={3}
            />
          </bufferGeometry>
          <lineBasicMaterial color="#00ffff" transparent opacity={0.65} />
        </line>
      ))}

      {network.nodes.map((position, index) => (
        <mesh
          key={`node-${index}`}
          ref={(el) => {
            nodeRefs.current[index] = el;
          }}
          position={position}
        >
          <sphereGeometry args={[0.045, 12, 12]} />
          <meshBasicMaterial color="#00ffff" />
        </mesh>
      ))}
    </group>
  );
}
