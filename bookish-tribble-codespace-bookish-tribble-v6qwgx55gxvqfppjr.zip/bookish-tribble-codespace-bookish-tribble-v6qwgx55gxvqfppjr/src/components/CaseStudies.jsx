import { Link } from "react-router-dom";

const caseStudies = [
  {
    title: "Industrial Expansion EIA",
    summary:
      "Delivered baseline studies, impact modeling, and regulator-ready documentation for a complex expansion program.",
    outcome: "Approval cycle shortened by 6 weeks with zero revision rounds.",
    serviceLink: "/services/eia",
  },
  {
    title: "Urban Development IEE",
    summary:
      "Prepared accelerated screening reports, mitigation planning, and compliance matrices for a phased urban project.",
    outcome: "Submission accepted on first review and moved directly to decision stage.",
    serviceLink: "/services/iee",
  },
  {
    title: "ESG and Audit Recovery",
    summary:
      "Conducted multi-site audits, identified compliance gaps, and deployed an ESG reporting framework.",
    outcome: "Raised readiness score from 63% to 92% in two reporting cycles.",
    serviceLink: "/services/esg-reporting",
  },
];

export default function CaseStudies() {
  return (
    <section id="cases" className="rounded-3xl border border-white/20 bg-white/10 p-6 shadow-[0_30px_80px_rgba(0,0,0,0.45)] backdrop-blur-2xl md:p-10">
      <p className="text-xs tracking-[0.3em] text-emerald-300/80">PROOF OF DELIVERY</p>
      <h2 className="mt-3 text-3xl font-semibold text-white md:text-4xl">Case Studies and Outcomes</h2>
      <p className="mt-4 max-w-3xl text-sm text-white/75 md:text-base">
        Each engagement is structured around approval speed, compliance confidence, and measurable ESG impact.
      </p>

      <div className="mt-7 grid gap-4 md:grid-cols-3">
        {caseStudies.map((item) => (
          <article key={item.title} className="rounded-2xl border border-white/15 bg-black/35 p-5">
            <h3 className="text-lg font-semibold text-emerald-300">{item.title}</h3>
            <p className="mt-3 text-sm text-white/75">{item.summary}</p>
            <p className="mt-4 rounded-xl border border-emerald-200/20 bg-emerald-300/10 px-3 py-2 text-sm text-emerald-100">
              {item.outcome}
            </p>
            <Link
              to={item.serviceLink}
              className="mt-5 inline-flex rounded-full border border-white/30 px-4 py-2 text-xs font-semibold tracking-[0.12em] text-white transition hover:border-emerald-300 hover:text-emerald-200"
            >
              VIEW SOLUTION
            </Link>
          </article>
        ))}
      </div>
    </section>
  );
}
