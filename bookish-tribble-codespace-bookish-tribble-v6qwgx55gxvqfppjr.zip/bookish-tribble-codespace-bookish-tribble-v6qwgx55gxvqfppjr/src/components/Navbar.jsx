import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useCommunity } from "../context/CommunityContext";
import logoSvg from "../logo.svg";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const { currentUser } = useCommunity();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-[#071220]/90 shadow-[0_2px_20px_rgba(0,0,0,0.5)] backdrop-blur-md"
          : "bg-[#071220]/45 backdrop-blur-sm"
      }`}
    >
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-3">
          <img
            src="/assets/logo.png"
            alt="EnviroCore logo"
            onError={(e) => {
              e.currentTarget.onerror = null;
              e.currentTarget.src = logoSvg;
            }}
            className="h-11 w-11 object-contain drop-shadow-[0_2px_8px_rgba(0,0,0,0.35)]"
          />
          <span className="text-xl font-bold tracking-wide text-white">EnviroCore</span>
        </Link>

        {/* Nav links */}
        <nav className="hidden items-center gap-8 md:flex">
          <Link to="/" className="text-slate-300 transition hover:text-emerald-400">
            Home
          </Link>
          <a href="/#services" className="text-slate-300 transition hover:text-emerald-400">
            Services
          </a>
          <Link to="/community" className="text-slate-300 transition hover:text-emerald-400">
            Community
          </Link>
          {currentUser?.role === "admin" ? (
            <Link to="/community/admin" className="text-slate-300 transition hover:text-emerald-400">
              Admin
            </Link>
          ) : null}
        </nav>

        {/* CTA */}
        <a
          href="/#proposal"
          className="rounded-full bg-emerald-500 px-5 py-2 text-sm font-semibold text-black transition hover:bg-emerald-400 hover:shadow-[0_0_20px_rgba(52,211,153,0.5)]"
        >
          Get a Proposal
        </a>
      </nav>
    </header>
  );
}
