export const servicesData = [
  {
    slug: "eia",
    title: "Environmental Impact Assessment (EIA)",
    summary:
      "Full-scale environmental studies, impact prediction, mitigation plans, and regulatory approvals.",
    intro:
      "Complete EIA studies including baseline surveys, impact prediction, mitigation planning, and submission to regulatory authorities.",
    points: [
      "Baseline Environmental Studies",
      "Impact Prediction and Modeling",
      "Mitigation and EMP Design",
      "Regulatory Submission Support",
    ],
  },
  {
    slug: "iee",
    title: "Initial Environmental Examination (IEE)",
    summary:
      "Fast-track environmental clearance documentation for focused development projects.",
    intro:
      "Accelerated IEE documentation for projects requiring fast environmental clearance and practical compliance planning.",
    points: [
      "Project Screening and Scope Definition",
      "Site Visit and Risk Profiling",
      "Submission-Ready IEE Reports",
      "Authority Clarification Support",
    ],
  },
  {
    slug: "audit-compliance",
    title: "Environmental Audit and Compliance",
    summary:
      "Field audits, compliance gap analysis, and corrective action frameworks for operational assurance.",
    intro:
      "Site audits with actionable compliance gap analysis and corrective roadmaps for sustained regulatory performance.",
    points: [
      "Regulatory Compliance Verification",
      "Gap Analysis and Corrective Actions",
      "Monitoring and Reporting Frameworks",
      "Audit Closeout Support",
    ],
  },
  {
    slug: "esg-reporting",
    title: "ESG Strategy and Reporting",
    summary:
      "Carbon tracking, sustainability KPIs, and investor-ready ESG disclosures.",
    intro:
      "Structured ESG advisory with KPI mapping, governance support, and investor-ready sustainability reporting.",
    points: [
      "Materiality and KPI Mapping",
      "Carbon and Sustainability Indicators",
      "ESG Narrative and Disclosure Drafting",
      "Leadership Reporting Dashboards",
    ],
  },
];

export function getServiceBySlug(slug) {
  return servicesData.find((service) => service.slug === slug);
}
