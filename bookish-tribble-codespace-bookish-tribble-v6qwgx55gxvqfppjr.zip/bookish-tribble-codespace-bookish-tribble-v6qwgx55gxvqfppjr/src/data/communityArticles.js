export const communityArticles = [
  {
    slug: "eia-faster-approval-guide",
    type: "Blog",
    category: "EIA",
    title: "How To Prepare an EIA That Gets Approved Faster",
    readTime: "6 min read",
    publishedAt: "April 2026",
    excerpt:
      "A practical guide to baseline studies, stakeholder concerns, and documentation quality that reduces revision loops.",
    featured: true,
    sections: [
      {
        heading: "Start with the project story",
        body:
          "Decision makers approve faster when the project purpose, location, and potential impact pathways are explained in a clear sequence. The report should begin with the site context, the project scope, and the likely environmental receptors before moving into technical detail.",
      },
      {
        heading: "Use a strong evidence package",
        body:
          "Baseline surveys, field photographs, maps, and monitoring tables should not feel detached from the narrative. They need to support the mitigation logic and show that the consultant understands the site and the surrounding community.",
      },
      {
        heading: "Keep mitigation practical",
        body:
          "The best EIAs do not overload regulators with generic language. They recommend site-specific mitigation, a realistic environmental management plan, and a monitoring schedule that can be implemented by the project team.",
      },
    ],
    takeaways: [
      "Lead with project context and impact pathways.",
      "Align field evidence with each major claim.",
      "Make mitigation actions practical and measurable.",
    ],
  },
  {
    slug: "iee-vs-eia-decision-guide",
    type: "Article",
    category: "IEE",
    title: "IEE vs EIA: Choosing the Right Path for Your Project",
    readTime: "5 min read",
    publishedAt: "April 2026",
    excerpt:
      "Understand project scale thresholds, submission expectations, and common mistakes in early compliance planning.",
    featured: false,
    sections: [
      {
        heading: "Know the decision threshold",
        body:
          "The first step is to identify whether the project triggers an IEE or a full EIA. The scale, sensitivity of the site, and likely impact footprint all matter. Starting with the wrong path often creates delays and avoidsable revision cycles.",
      },
      {
        heading: "Match the level of analysis",
        body:
          "An IEE should be concise but still complete enough to justify approval. An EIA needs deeper baseline analysis, more rigorous impact prediction, and stronger mitigation mapping. The report depth should match the project risk profile.",
      },
      {
        heading: "Plan for submission early",
        body:
          "Projects move faster when the consultant builds the submission strategy at the start, not at the end. This means pre-checking authority requirements, listing supporting documents, and assigning responsibility for revisions before filing.",
      },
    ],
    takeaways: [
      "Choose the analysis depth based on risk and site sensitivity.",
      "Pre-check authority requirements before writing.",
      "Use a submission plan to avoid rework.",
    ],
  },
  {
    slug: "esg-reporting-that-builds-trust",
    type: "Blog",
    category: "ESG",
    title: "Building ESG Reporting That Investors Actually Trust",
    readTime: "7 min read",
    publishedAt: "April 2026",
    excerpt:
      "Turn ESG into a measurable management system with clear KPIs, governance ownership, and evidence-backed reporting.",
    featured: false,
    sections: [
      {
        heading: "Treat ESG as a management system",
        body:
          "ESG reporting works when it is connected to operating decisions. Instead of producing a decorative report at year-end, use ESG to define metrics, owners, review cycles, and actions that the leadership team can track over time.",
      },
      {
        heading: "Focus on evidence, not slogans",
        body:
          "Investors trust reports that show clear baselines, target-setting logic, and proof of implementation. A simple scorecard with source documents, photos, audit trails, and measurable progress is much stronger than broad claims.",
      },
      {
        heading: "Keep the narrative consistent",
        body:
          "The sustainability story should reflect what the business actually does. Good ESG reporting ties governance, environmental performance, and social impact into a single message that can be repeated across proposals, board decks, and disclosure packs.",
      },
    ],
    takeaways: [
      "Link ESG to operating decisions and review cycles.",
      "Use evidence-backed scorecards and source documents.",
      "Keep the narrative consistent across all channels.",
    ],
  },
  {
    slug: "industrial-audit-checklist",
    type: "Article",
    category: "Audit",
    title: "Environmental Audit Checklist for Industrial Operations",
    readTime: "8 min read",
    publishedAt: "April 2026",
    excerpt:
      "A field-tested checklist for compliance gaps, corrective actions, and ongoing monitoring to maintain approval readiness.",
    featured: false,
    sections: [
      {
        heading: "Start with compliance reality",
        body:
          "Industrial audits should begin by verifying permits, monitoring records, waste handling, and operating conditions as they actually exist on site. The goal is not only to spot gaps, but to understand why they appeared and how to close them.",
      },
      {
        heading: "Build a corrective action map",
        body:
          "Every audit finding should point to an owner, a deadline, and a practical fix. When the corrective action plan is clear, management can move from awareness to implementation quickly and avoid repeated compliance drift.",
      },
      {
        heading: "Track progress after the visit",
        body:
          "An audit adds real value when the consultant also supports follow-up. That can include rechecks, evidence collection, and a short closeout note that shows the organization has closed the loop on major observations.",
      },
    ],
    takeaways: [
      "Verify actual site conditions, not just documents.",
      "Assign an owner and deadline to every finding.",
      "Close the loop with follow-up verification.",
    ],
  },
];

export function getCommunityArticle(slug) {
  return communityArticles.find((article) => article.slug === slug);
}
